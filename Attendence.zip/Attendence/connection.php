<?php
$con = mysqli_connect("localhost", "root", "", "atendence_system");

?>
